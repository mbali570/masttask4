let cars = [];
let selectedCar = {};
let totalCost = 0;

function login() {
  const role = document.getElementById("role").value;
  document.getElementById("loginScreen").style.display = "none";
  if (role === "admin") {
    document.getElementById("adminScreen").style.display = "block";
  } else {
    document.getElementById("customerScreen").style.display = "block";
  }
}

function addCar() {
  const make = document.getElementById("carMake").value;
  const model = document.getElementById("carModel").value;
  const cost = document.getElementById("carCost").value;

  if (make && model && cost) {
    cars.push({ make, model, cost });
    alert("Car Added Successfully!");
    document.getElementById("carMake").value = "";
    document.getElementById("carModel").value = "";
    document.getElementById("carCost").value = "";
    updateCarList();
  }
}

function updateCarList() {
  const carList = document.getElementById("carList");
  carList.innerHTML = "";
  cars.forEach((car, index) => {
    let option = document.createElement("option");
    option.value = index;
    option.text = `${car.make} ${car.model} - $${car.cost}/day`;
    carList.appendChild(option);
  });
}

function showModal() {
  const carIndex = document.getElementById("carList").value;
  const days = document.getElementById("days").value;

  if (carIndex === "" || days === "") {
    alert("Please select a car and number of days");
    return;
  }

  selectedCar = cars[carIndex];
  totalCost = days * selectedCar.cost;

  document.getElementById("bookingDetails").innerText =
    `Car: ${selectedCar.make} ${selectedCar.model}\nDays: ${days}\nTotal: $${totalCost}`;

  document.getElementById("bookingModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("bookingModal").style.display = "none";
}

function confirmBooking() {
  const days = document.getElementById("days").value;
  document.getElementById("confirmationDetails").innerText =
    `Car: ${selectedCar.make} ${selectedCar.model}\nDays: ${days}\nTotal Due: $${totalCost}`;

  closeModal();
  document.getElementById("customerScreen").style.display = "none";
  document.getElementById("confirmationScreen").style.display = "block";
}